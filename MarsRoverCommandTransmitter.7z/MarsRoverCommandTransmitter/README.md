#Do the following to compile and run
######################################

mvn update
mvn clean install


#The above command will create a .jar inside the target folder.