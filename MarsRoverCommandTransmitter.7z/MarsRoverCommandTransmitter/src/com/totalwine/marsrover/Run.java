package com.totalwine.marsrover;

import com.totalwine.marsrover.controller.RoverController;
import com.totalwine.marsrover.dao.InMemoryInstructionDaoImpl;
import com.totalwine.marsrover.dao.InstructionDao;
import com.totalwine.marsrover.service.InstructionService;
import com.totalwine.marsrover.service.InstructionServiceImpl;
import com.totalwine.marsrover.transmitter.EmergencyTransmitter;
import com.totalwine.marsrover.transmitter.EmergencyTransmitterImpl;

public class Run {
	
	public static void main(String[] args) {
		
		//Setting up the environment
		InstructionDao dao = new InMemoryInstructionDaoImpl();
		InstructionService service = new InstructionServiceImpl(dao);
		EmergencyTransmitter emergencyTransmitter = new EmergencyTransmitterImpl();
		RoverController rover = new RoverController(service, emergencyTransmitter);
		
		//Move forward five spots
		rover.MoveForward(5);
			
		// turns right
		rover.TurnRight();
		
		//Move forward two spots
		rover.MoveForward(2);
		
		// turns right
		rover.TurnRight();
		
		//Move forward two spots
		rover.MoveForward(3);
		
		// turns right
		rover.TurnLeft();
		
		//Move backward one spot
		rover.MoveBackward(1);
		
		// turns right
		rover.TurnRight();
	}

}
