package com.totalwine.marsrover.dao;

public class HibernateInstructionDaoImpl  implements InstructionDao {

	/**
	 * extend your own implementation using Hibernate
	 */

}
