package com.totalwine.marsrover.service;

import java.util.List;

import com.totalwine.marsrover.model.Instruction;

public interface InstructionService {

	Instruction saveInstruction(Instruction instruction);
	Instruction updateInstruction(Instruction instruction);
	boolean deleteInsruction(long guid);
	List<Instruction> getAllInstructions();
	Instruction getInstruction(Long guid);
}
