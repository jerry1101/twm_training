package com.totalwine.marsrover.transmitter;

public interface EmergencyTransmitter {
	public void Transmit(String msg, int xCoordinate, int yCoordinate);
}
