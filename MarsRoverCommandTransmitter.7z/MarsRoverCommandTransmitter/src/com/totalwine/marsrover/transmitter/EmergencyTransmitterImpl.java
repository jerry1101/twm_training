package com.totalwine.marsrover.transmitter;

public class EmergencyTransmitterImpl implements EmergencyTransmitter{

	@Override
	public void Transmit(String msg, int xCoordinate, int yCoordinate) {
		System.out.println(msg + "[ XOrdinate=" + xCoordinate + ", YOrdinate=" + yCoordinate);
	}

}
