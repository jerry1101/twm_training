package com.yoogesh.marsrover;

import com.yoogesh.marsrover.controller.RoverController;
import com.yoogesh.marsrover.dao.InMemoryInstructionDaoImpl;
import com.yoogesh.marsrover.dao.InstructionDao;
import com.yoogesh.marsrover.service.InstructionService;
import com.yoogesh.marsrover.service.InstructionServiceImpl;
import com.yoogesh.marsrover.transmitter.EmergencyTransmitter;
import com.yoogesh.marsrover.transmitter.EmergencyTransmitterImpl;

public class Run {
	
	public static void main(String[] args) {
		
		//Setting up the environment
		InstructionDao dao = new InMemoryInstructionDaoImpl();
		InstructionService service = new InstructionServiceImpl(dao);
		EmergencyTransmitter emergencyTransmitter = new EmergencyTransmitterImpl();
		RoverController rover = new RoverController(service, emergencyTransmitter);
		
		//Move forward five spots
		rover.MoveForward(5);
			
		// turns right
		rover.TurnRight();
		
		//Move forward two spots
		rover.MoveForward(2);
		
		// turns right
		rover.TurnRight();
		
		//Move forward two spots
		rover.MoveForward(3);
		
		// turns right
		rover.TurnLeft();
		
		//Move backward one spot
		rover.MoveBackward(1);
		
		// turns right
		rover.TurnRight();
	}

}
