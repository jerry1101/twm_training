package com.yoogesh.marsrover.dao;

public class HibernateInstructionDaoImpl  implements InstructionDao {

	/**
	 * extend your own implementation using Hibernate
	 */

}
