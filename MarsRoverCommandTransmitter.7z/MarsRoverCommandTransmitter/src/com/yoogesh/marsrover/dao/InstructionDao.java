package com.yoogesh.marsrover.dao;

import java.util.List;

import com.yoogesh.marsrover.model.Instruction;

public interface InstructionDao {
	
	// Create
	default Instruction createInstruction(Instruction instruction) {
		throw new RuntimeException("The current persistence API has not implemneted this method.");
	}

	// Update
	default Instruction updateInstruction(Instruction instruction) {
		throw new RuntimeException("The current persistence API has not implemneted this method.");
	}

	// Delete
	default boolean deleteInsruction(long guid) {
		throw new RuntimeException("The current persistence API has not implemneted this method.");
	}

	// Read All
	default List<Instruction> getAllInstructions(){
		throw new RuntimeException("The current persistence API has not implemneted this method.");
	}

	 // Read single using primary key
	default Instruction getInstruction(Long guid) {
		throw new RuntimeException("The current persistence API has not implemneted this method.");
	}

}
