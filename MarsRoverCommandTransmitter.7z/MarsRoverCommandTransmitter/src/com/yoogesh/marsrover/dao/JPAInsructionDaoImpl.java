package com.yoogesh.marsrover.dao;

public class JPAInsructionDaoImpl implements InstructionDao{

	/**
	 * provide your own implementation using Java Persistence API (JPA) i.e. entityManager
	 */

}
