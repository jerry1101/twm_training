package com.yoogesh.marsrover.model;

public class Instruction {
	
	private Long uid;
	private String currentDirection = "North";
	private String facingToward = "Straight";
	private int xCoordinate = 0;
	private int yCoordinate = 0;
	private int currentQuadrant;
	private Instruction previousInstruction;
	
	
	
	public Instruction() {
		super();
	}

	public Instruction(Long uid, String currentDirection, String facingToward, int xCoordinate, int yCoordinate,
			int currentQuadrant, Instruction previousInstruction) {
		super();
		this.uid = uid;
		this.currentDirection = currentDirection;
		this.facingToward = facingToward;
		this.xCoordinate = xCoordinate;
		this.yCoordinate = yCoordinate;
		this.currentQuadrant = currentQuadrant;
		this.previousInstruction = previousInstruction;
	}

	public Long getUid() {
		return uid;
	}

	public void setUid(Long uid) {
		this.uid = uid;
	}

	public String getCurrentDirection() {
		return currentDirection;
	}

	public void setCurrentDirection(String currentDirection) {
		this.currentDirection = currentDirection;
	}

	public String getFacingToward() {
		return facingToward;
	}

	public void setFacingToward(String facingToward) {
		this.facingToward = facingToward;
	}

	public int getxCoordinate() {
		return xCoordinate;
	}

	public void setxCoordinate(int xCoordinate) {
		this.xCoordinate = xCoordinate;
	}

	public int getyCoordinate() {
		return yCoordinate;
	}

	public void setyCoordinate(int yCoordinate) {
		this.yCoordinate = yCoordinate;
	}

	public int getCurrentQuadrant() {
		return currentQuadrant;
	}

	public void setCurrentQuadrant(int currentQuadrant) {
		this.currentQuadrant = currentQuadrant;
	}

	public Instruction getPreviousInstruction() {
		return previousInstruction;
	}

	public void setPreviousInstruction(Instruction previousInstruction) {
		this.previousInstruction = previousInstruction;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((currentDirection == null) ? 0 : currentDirection.hashCode());
		result = prime * result + currentQuadrant;
		result = prime * result + ((facingToward == null) ? 0 : facingToward.hashCode());
		result = prime * result + ((previousInstruction == null) ? 0 : previousInstruction.hashCode());
		result = prime * result + ((uid == null) ? 0 : uid.hashCode());
		result = prime * result + xCoordinate;
		result = prime * result + yCoordinate;
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Instruction other = (Instruction) obj;
		if (currentDirection == null) {
			if (other.currentDirection != null)
				return false;
		} else if (!currentDirection.equals(other.currentDirection))
			return false;
		if (currentQuadrant != other.currentQuadrant)
			return false;
		if (facingToward == null) {
			if (other.facingToward != null)
				return false;
		} else if (!facingToward.equals(other.facingToward))
			return false;
		if (previousInstruction == null) {
			if (other.previousInstruction != null)
				return false;
		} else if (!previousInstruction.equals(other.previousInstruction))
			return false;
		if (uid == null) {
			if (other.uid != null)
				return false;
		} else if (!uid.equals(other.uid))
			return false;
		if (xCoordinate != other.xCoordinate)
			return false;
		if (yCoordinate != other.yCoordinate)
			return false;
		return true;
	}

	@Override
	public String toString() {
		return "Instruction [uid=" + uid + ", currentDirection=" + currentDirection + ", facingToward=" + facingToward
				+ ", xCoordinate=" + xCoordinate + ", yCoordinate=" + yCoordinate + "]";
	}
	
	
}
