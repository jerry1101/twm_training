package com.yoogesh.marsrover.service;

import java.util.List;

import com.yoogesh.marsrover.dao.InstructionDao;
import com.yoogesh.marsrover.model.Instruction;

public class InstructionServiceImpl implements InstructionService{
	
	InstructionDao instructionDao;
	
	public InstructionServiceImpl(InstructionDao instructionDao) {
		this.instructionDao = instructionDao;
	}

	@Override
	public Instruction saveInstruction(Instruction instruction) {
		return instructionDao.createInstruction(instruction);
	}

	@Override
	public Instruction updateInstruction(Instruction instruction) {
		return instructionDao.updateInstruction(instruction);
	}

	@Override
	public boolean deleteInsruction(long guid) {
		return instructionDao.deleteInsruction(guid);
	}

	@Override
	public List<Instruction> getAllInstructions() {
		return instructionDao.getAllInstructions();
	}

	@Override
	public Instruction getInstruction(Long guid) {
		return instructionDao.getInstruction(guid);
	}

}
