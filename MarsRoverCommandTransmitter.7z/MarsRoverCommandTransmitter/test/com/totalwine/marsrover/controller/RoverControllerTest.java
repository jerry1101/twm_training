package com.totalwine.marsrover.controller;


import org.junit.Assert;
import org.junit.Test;

public class RoverControllerTest {
	
	
	
	@Test
	public void test() {
		Assert.assertFalse(false);

	}
	
	

}
