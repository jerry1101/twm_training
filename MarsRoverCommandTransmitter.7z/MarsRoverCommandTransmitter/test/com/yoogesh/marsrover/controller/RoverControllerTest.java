package com.yoogesh.marsrover.controller;

import org.junit.Assert;
import org.junit.Test;

import com.yoogesh.marsrover.dao.InstructionDao;
import com.yoogesh.marsrover.dao.TestInstructionDatabaseDaoImpl;
import com.yoogesh.marsrover.service.InstructionServiceImpl;
import com.yoogesh.marsrover.transmitter.EmergencyTransmitter;
import com.yoogesh.marsrover.transmitter.EmergencyTransmitterImpl;

public class RoverControllerTest {
	
	public RoverController setup() {
		
		//Integration test!! Using Test database
		InstructionDao dao = new TestInstructionDatabaseDaoImpl();
		
		InstructionServiceImpl service = new InstructionServiceImpl(dao);
		EmergencyTransmitter emergencyTransmitter = new EmergencyTransmitterImpl();
		RoverController rover = new RoverController(service, emergencyTransmitter);
		return rover;
	}
	
	@Test
	public void testMoveForward() {
		RoverController rover = setup();
		
		//Move forward five spots
		rover.MoveForward(5);
		
		Assert.assertEquals(0, rover.GetXCoordinate());
		Assert.assertEquals(5, rover.GetYCoordinate());
	}
	
	@Test
	public void testMoveBackward() {
		RoverController rover = setup();
		
		//Move backward one spot
		rover.MoveBackward(1);

		Assert.assertEquals(0, rover.GetXCoordinate());
		Assert.assertEquals(-1, rover.GetYCoordinate());
	}
	
	
	
	@Test
	public void testMoveForward_multiple_scenario() {
		RoverController rover = setup();
		rover.MoveForward(5);
		rover.TurnRight();
		rover.MoveBackward(3);
		rover.TurnRight();
		rover.MoveForward(1);
		rover.TurnRight();
		rover.MoveBackward(1);
		rover.TurnRight();
		rover.MoveBackward(1);
		rover.TurnRight();
		Assert.assertEquals(-2, rover.GetXCoordinate());
		Assert.assertEquals(3, rover.GetYCoordinate());
		Assert.assertEquals("East", rover.GetDirection());
	}
	
	@Test
	public void testMoveBackward_Multiple_Scenario() {
		
		RoverController rover = setup();
		
		//Move forward five spots
		rover.MoveForward(5);
			
		// turns right
		rover.TurnRight();
		
		//Move forward two spots
		rover.MoveForward(2);
		
		// turns right
		rover.TurnRight();
		
		//Move forward two spots
		rover.MoveForward(3);
		
		rover.TurnRight();
		
		rover.MoveForward(3);
		
		rover.TurnRight();
		
		rover.MoveForward(3);
		
		// turns right
		rover.TurnLeft();
		
		//Move backward one spot
		rover.MoveBackward(1);
		
		// turns right
		rover.TurnRight();
		
		Assert.assertEquals(0, rover.GetXCoordinate());
		Assert.assertEquals(5, rover.GetYCoordinate());
	}


	@Test
	public void testTurnRight() {
		RoverController rover = setup();
		rover.TurnRight();
		Assert.assertEquals("East", rover.GetDirection());
		
	}
	
	@Test
	public void testTurnRight_multiple_scenario() {
		RoverController rover = setup();
		rover.MoveForward(5);
		rover.TurnRight();
		Assert.assertEquals("East", rover.GetDirection());
		
	}
	
	@Test
	public void testTurnLeft() {
		RoverController rover = setup();
		rover.TurnLeft();
		Assert.assertEquals("West", rover.GetDirection());
	}
	
	@Test
	public void testTurnLeft_multiple_scenario() {
		RoverController rover = setup();
		rover.MoveForward(5);
		rover.TurnRight();
		rover.MoveForward(2);
		rover.TurnRight();
		rover.MoveForward(3);
		rover.TurnLeft();
		Assert.assertEquals("East", rover.GetDirection());
	}

	@Test
	public void testEmergencyTransmitterSignal() {
		RoverController rover = setup();
		rover.MoveBackward(5);
	}

}
