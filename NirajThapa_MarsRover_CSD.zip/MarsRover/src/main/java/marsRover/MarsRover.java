package marsRover;

public interface MarsRover {

	public void MoveForward(int spots);
	public void MoveBackward(int spots);
	public void TurnLeft();
	public void TurnRight();
	public String GetDirection();
	public int GetXCoordinate();
	public int GetYCoordinate();
	

}
