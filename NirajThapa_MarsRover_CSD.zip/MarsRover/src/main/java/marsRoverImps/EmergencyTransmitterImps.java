package marsRoverImps;

import marsRover.EmergencyTransmitter;

public class EmergencyTransmitterImps implements EmergencyTransmitter{

	
	@Override
	public void Transmit(String msg, int xCoordinate, int yCoordinate) {
		if (xCoordinate<0 || yCoordinate<0) {
			System.out.println("***********"+msg+": Rover postion is in NEVERLAND -TRANSMIT MESSAGE******");
			throw new IllegalArgumentException(
					"Warning!! Rover wanders into a neverLand...");
					
		}
		
	}


	}

	


