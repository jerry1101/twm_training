package marsRoverImps;

import marsRover.MarsRover;

public class RoverImps implements MarsRover{
	
	private int x=0;
	private int y=0;
	private String facing = "North";
	private EmergencyTransmitterImps emergency = new EmergencyTransmitterImps();
	

	@Override
	public void MoveForward(int spots) {
		if(facing.equalsIgnoreCase("North") ) {
		y+=spots;
		}else if(facing.equalsIgnoreCase("South")){
		y-=spots;
	}else if(facing.equalsIgnoreCase("East")) {
		x+=spots;
	}else {
		x-=spots;
		
	}
		emergency.Transmit("FORWARD MOVEMENT", x, y);
			
	}

	@Override
	public void MoveBackward(int spots) {
		if(facing.equalsIgnoreCase("North")) {
			y-=spots;
		}else if(facing.equalsIgnoreCase("South")){
			y+=spots;
		}else if(facing.equalsIgnoreCase("East")) {
			x-=spots;
		}else {
			x+=spots;
		}
		
		emergency.Transmit("BACKWARD MOVEMENT", x, y);
		
	}

	@Override
	public void TurnLeft() {
		if(facing.equalsIgnoreCase("North")) {
			facing ="west";
		}else if(facing.equalsIgnoreCase("West")) {
			facing ="south";
		}else if(facing.equalsIgnoreCase("South")) {
			facing="east";
		}else {
			facing="North";
		}
		
	}

	@Override
	public void TurnRight() {
		if(facing.equalsIgnoreCase("North")) {
			facing ="east";
		}else if(facing.equalsIgnoreCase("east")) {
			facing ="south";
		}else if(facing.equalsIgnoreCase("south")) {
			facing="west";
		}else {
			facing="North";
		}
		
	}

	@Override
	public String GetDirection() {
		return facing;
	}

	@Override
	public int GetXCoordinate() {
		return x;
	}

	@Override
	public int GetYCoordinate() {
		return y;
	}
	

}
