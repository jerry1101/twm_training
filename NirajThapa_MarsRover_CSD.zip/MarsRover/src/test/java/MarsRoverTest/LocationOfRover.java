package MarsRoverTest;

import org.junit.Assert;
import org.junit.Test;

import marsRover.MarsRover;
import marsRoverImps.RoverImps;

public class LocationOfRover {
	MarsRover rover = new RoverImps();

	@Test
	public void verifyInitialPostionOfRover() {
		System.out.println("x is: " + rover.GetXCoordinate() + " , y is: " + rover.GetYCoordinate());
		System.out.println("positon is " + rover.GetDirection());
		System.out.println("This was my initial location of rover ");
		Assert.assertEquals(0, rover.GetXCoordinate());
		Assert.assertEquals(0, rover.GetYCoordinate());
		Assert.assertEquals("North", rover.GetDirection());
	}

	@Test
	public void testRoverMovtZeroSpot() {
		rover.MoveForward(0);
		System.out.println("x is: " + rover.GetXCoordinate() + " , y is: " + rover.GetYCoordinate());
		System.out.println("positon is " + rover.GetDirection());
		Assert.assertEquals(0, rover.GetXCoordinate());
		Assert.assertEquals("North", rover.GetDirection());
	}
	
	@Test
    public void testRoverEastFacingPostion() {
	rover.MoveForward(3);
	rover.TurnRight();
    Assert.assertEquals("east", rover.GetDirection());
    }
	
    
    @Test
    public void testRoverWesttFacingPostion() {
    rover.MoveForward(5);
    rover.TurnLeft();
    Assert.assertEquals("west", rover.GetDirection());
    }
    
    @Test
    public void testRoverSouthFacingPostion() {
    rover.MoveForward(5);
    rover.TurnRight();
    rover.MoveForward(5);
    rover.TurnRight();
    Assert.assertEquals("south", rover.GetDirection());
    }
	
	@Test(expected = IllegalArgumentException.class)
    public void testRoverSouthFacingPostionNeverLand() {
    rover.MoveForward(5);
    rover.TurnLeft();
    rover.MoveForward(5);
    rover.TurnLeft();
    Assert.assertEquals("South", rover.GetDirection());
    }
    
	@Test(expected = IllegalArgumentException.class)
	public void testEmergencyTransmissionMsgOnlyFWDMovt() {
		rover.MoveForward(-5);
		System.out.println("x is: " + rover.GetXCoordinate() + " , y is: " + rover.GetYCoordinate());
		System.out.println("positon is " + rover.GetDirection());
	}
	
	@Test(expected = IllegalArgumentException.class)
	public void testEmergencyTransmissionMsgOnlyBCKMovt() {
		rover.MoveBackward(5);
		System.out.println("x is: " + rover.GetXCoordinate() + " , y is: " + rover.GetYCoordinate());
		System.out.println("positon is " + rover.GetDirection());
	}

	@Test(expected = IllegalArgumentException.class)
	public void testEmergencyTransmissionMsgFWDMovt() {
		rover.TurnRight();
		rover.MoveForward(2);
		rover.TurnRight();
		rover.MoveForward(2);
		System.out.println("x is: " + rover.GetXCoordinate() + " , y is: " + rover.GetYCoordinate());
		System.out.println("positon is " + rover.GetDirection());
	}

	@Test(expected = IllegalArgumentException.class)
	public void testEmergencyTransmissionMsgBCKMovt() {
		rover.MoveBackward(5);
		rover.TurnLeft();
		rover.MoveForward(3);
		System.out.println("x is: " + rover.GetXCoordinate() + " , y is: " + rover.GetYCoordinate());
		System.out.println("positon is " + rover.GetDirection());
	}
	

	@Test
	public void myFinalLocationOfRover() {
		rover.MoveForward(5);
		rover.TurnRight();
		rover.MoveForward(2);
		rover.TurnRight();
		rover.MoveForward(3);
		rover.TurnLeft();
		rover.MoveBackward(1);
		rover.TurnRight();
		System.out.println("x is: " + rover.GetXCoordinate() + " , y is: " + rover.GetYCoordinate());
		System.out.println("positon is " + rover.GetDirection());
		System.out.println("THIS IS MY FINAL ROVER LOCATION ");
		Assert.assertEquals(1, rover.GetXCoordinate());
		Assert.assertEquals(2, rover.GetYCoordinate());
		Assert.assertEquals("south", rover.GetDirection());

	}

}
