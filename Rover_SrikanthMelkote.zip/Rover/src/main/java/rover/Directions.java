package rover;

public interface Directions {
    public String turnRight(String direction);
    public String turnLeft(String direction);
}
