package rover;

public interface Movement {
    public int[] moveForward(int[] coordinates, int spots, String direction);
    public int[] moveBackward(int[] coordinates, int spots, String direction);
}
