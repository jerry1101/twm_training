package rover;

public interface Signal {
    public void alarm( String msg);
    public String status();
}
