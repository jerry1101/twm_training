package rover;

public interface Transmitter {
    public void transmit(String msg, int xCoordinate, int yCoordinate);
}
