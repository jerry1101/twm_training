package rover.impl;

import rover.Directions;

public class DirectionsImpl implements Directions {
    @Override
    public String turnRight(String direction) {
        if(direction.equalsIgnoreCase("NORTH")) {
            direction ="EAST";
        }else if(direction.equalsIgnoreCase("EAST")) {
            direction ="SOUTH";
        }else if(direction.equalsIgnoreCase("SOUTH")) {
            direction="WEST";
        }else {
            direction="NORTH";
        }
        return direction;
    }

    @Override
    public String turnLeft(String direction) {
        if(direction.equalsIgnoreCase("NORTH")) {
            direction = "WEST";
        }else if(direction.equalsIgnoreCase("WEST")) {
            direction = "SOUTH";
        }else if(direction.equalsIgnoreCase("SOUTH")) {
            direction = "EAST";
        }else {
            direction = "NORTH";
        }
        return direction;
    }
}
