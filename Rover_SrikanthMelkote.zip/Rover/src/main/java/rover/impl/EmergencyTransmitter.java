package rover.impl;

import rover.Signal;
import rover.Transmitter;

public class EmergencyTransmitter implements Transmitter {

    private Signal signal;

    public EmergencyTransmitter(Signal signal){
        this.signal = signal;
    }
    @Override
    public void transmit(String msg, int xCoordinate, int yCoordinate) {
        signal.alarm(msg+" at "+xCoordinate+" at "+yCoordinate);
    }

}
