package rover.impl;

import rover.Signal;

public class HomeSignal implements Signal {
    private String message;
    @Override
    public void alarm( String msg) {
        this.message = msg;
    }

    @Override
    public String status() {
        return this.message;
    }
}
