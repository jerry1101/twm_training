package rover.impl;

import rover.Movement;

public class MovementImpl implements Movement {

    @Override
    public int[] moveForward(int[] coordinates, int spots, String direction) {

        if("NORTH".equals(direction)){
            coordinates[1] += spots;
        }else if ("SOUTH".equals(direction)) {
            coordinates[1] -= spots;
        }else if ("EAST".equals(direction)) {
            coordinates[0] += spots;
        }else if ("WEST".equals(direction)) {
            coordinates[0] -= spots;
        }
        return coordinates;
    }

    @Override
    public int[] moveBackward(int[] coordinates, int spots, String direction) {
        if("NORTH".equals(direction)){
            coordinates[1] -= spots;
        }else if ("SOUTH".equals(direction)) {
            coordinates[1] += spots;
        }else if ("EAST".equals(direction)) {
            coordinates[0] -= spots;
        }else if ("WEST".equals(direction)){
            coordinates[0] += spots;
        }

        return coordinates;
    }
}
