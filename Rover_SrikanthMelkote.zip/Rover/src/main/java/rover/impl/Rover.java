package rover.impl;

import rover.Directions;
import rover.Movement;
import rover.Transmitter;

public class Rover {
    private int[] coordinates = {0,0};
    private Movement movement;
    private Directions directions;
    private Transmitter transmitter;
    private String direction;
    private String TRANSMIT_MSG = "Rover moved into Neverland";

    public Rover(Movement movement, Directions directions, Transmitter transmitter, String direction){
        this.movement = movement;
        this.directions = directions;
        this.direction = direction;
        this.transmitter = transmitter;
    }

    public void moveForward(int spots) {
        if (spots < 0) {
            moveBackward(Math.abs(spots));
        }else{
            coordinates = movement.moveForward(coordinates, spots, direction);
            checkIfRoverInNeverLand();
        }


    }

    public void moveBackward(int spots) {
        if (spots < 0) {
            moveForward(Math.abs(spots));
        }else{
            coordinates = movement.moveBackward(coordinates, spots, direction);
            checkIfRoverInNeverLand();
        }

    }
    public void turnLeft(){

        direction = directions.turnLeft(direction);
    }
    public void turnRight(){

        direction = directions.turnRight(direction);
    }
    public String getDirection(){
        return direction;
    }
    public int getXCoOrdinate(){
        return coordinates[0];
    }
    public int getYCoOrdinate(){
        return coordinates[1];
    }
    private void checkIfRoverInNeverLand() {
        if (coordinates[0] < 0 || coordinates[1] < 0) {
            transmitter.transmit(TRANSMIT_MSG, coordinates[0], coordinates[1]);
        }
    }
}
