package com.totalwine.rover.dao;

public interface Rover {

    public void moveForward(int spots);
    public void moveBackward(int spots);
    public void turnLeft();
    public void turnRight();
    public String getDirection();
    public int getXCoordinate();
    public int getYCoordinate();


}