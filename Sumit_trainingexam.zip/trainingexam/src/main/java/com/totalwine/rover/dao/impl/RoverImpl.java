package com.totalwine.rover.dao.impl;


import com.totalwine.rover.dao.Rover;
import com.totalwine.rover.service.EmergencyTransmitterService;

public class RoverImpl implements Rover {

    private int x=0;
    private int y=0;
    private String facing = "North";

    private EmergencyTransmitterService transmitter;

    public RoverImpl(EmergencyTransmitterService service){
        this.transmitter = service;
    }

    @Override
    public void moveForward(int spots) {
        if(facing.equalsIgnoreCase("North") ) {
            y+=spots;
        }else if(facing.equalsIgnoreCase("South")){
            y-=spots;
        }else if(facing.equalsIgnoreCase("east")) {
            x+=spots;
        }else {
            x-=spots;
        }

        callTransmitter();
    }

    @Override
    public void moveBackward(int spots) {
        if(facing.equalsIgnoreCase("North")) {
            y-=spots;
        }else if(facing.equalsIgnoreCase("South")){
            y+=spots;
        }else if(facing.equalsIgnoreCase("east")) {
            x-=spots;
        }else {
            x+=spots;
        }
        callTransmitter();

    }

    @Override
    public void turnLeft() {
        if(facing.equalsIgnoreCase("North")) {
            facing ="west";
        }else if(facing.equalsIgnoreCase("west")) {
            facing ="south";
        }else if(facing.equalsIgnoreCase("south")) {
            facing="east";
        }else {
            facing="North";
        }

    }

    @Override
    public void turnRight() {
        if(facing.equalsIgnoreCase("North")) {
            facing ="east";
        }else if(facing.equalsIgnoreCase("east")) {
            facing ="south";
        }else if(facing.equalsIgnoreCase("south")) {
            facing="west";
        }else {
            facing="North";
        }

    }

    @Override
    public String getDirection() {
        return facing;
    }

    @Override
    public int getXCoordinate() {
        return x;
    }

    @Override
    public int getYCoordinate() {
        return y;
    }

    private void callTransmitter() {
        if (x<0 || y<0){
            transmitter.Transmit("Transmitting Emergency",x,y);
        }
    }
}

