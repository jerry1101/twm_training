package com.totalwine.rover.service;

public interface EmergencyTransmitterService {

    public void Transmit(String msg, int xCoordinate, int yCoordinate);
}
