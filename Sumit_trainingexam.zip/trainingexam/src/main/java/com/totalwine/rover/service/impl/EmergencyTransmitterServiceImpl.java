package com.totalwine.rover.service.impl;

import com.totalwine.rover.service.EmergencyTransmitterService;

public class EmergencyTransmitterServiceImpl implements EmergencyTransmitterService {

    @Override
    public void Transmit(String msg, int xCoordinate, int yCoordinate) {
        System.out.println("Distress signal is received"+ msg + "coordinates - "+xCoordinate +", "+yCoordinate);
    }
}