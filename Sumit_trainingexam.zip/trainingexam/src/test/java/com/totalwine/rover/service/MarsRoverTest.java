package com.totalwine.rover.service;

import com.totalwine.rover.dao.Rover;
import com.totalwine.rover.dao.impl.RoverImpl;
import com.totalwine.rover.service.impl.EmergencyTransmitterServiceImpl;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.mockito.Mock;

import static org.mockito.Mockito.*;


public class MarsRoverTest {

    Rover rover = null;

    @Mock
    EmergencyTransmitterService transmitter;

    @Before
    public void beforeEach() {
        transmitter = mock(EmergencyTransmitterServiceImpl.class);
        rover = new RoverImpl(transmitter);
    }


    @Test
    public void testRover() {

        rover.moveForward(5);
        rover.turnRight();

        System.out.println("x is: "+rover.getXCoordinate()+
                " , y is: "+rover.getYCoordinate());
        System.out.println("position is "+rover.getDirection());
    }


    //Test default position should be x=0, y=0 and direction = North

    @Test
    public void testDefaultPosition() {

        Assert.assertEquals(rover.getXCoordinate(), 0);
        Assert.assertEquals(rover.getYCoordinate(), 0);
        Assert.assertEquals(rover.getDirection(), "North");
    }


    //Test Rover move forward & backward 10 spots - direction  remain same as North

    @Test
    public void testMoveSameDirection() {
        rover.moveForward(5);
        rover.moveForward(5);
        rover.moveBackward(5);
        rover.moveBackward(5);
        Assert.assertEquals(rover.getXCoordinate(), 0);
        Assert.assertEquals(rover.getYCoordinate(), 0);
        Assert.assertEquals(rover.getDirection(), "North");
    }

    //Test Rover move forward & backward 10 spots & turn right  - direction should change to East

    @Test
    public void testRight() {
        rover.moveForward(5);
        rover.moveForward(5);
        rover.moveBackward(5);
        rover.moveBackward(5);
        rover.turnRight();
        Assert.assertEquals(rover.getXCoordinate(), 0);
        Assert.assertEquals(rover.getYCoordinate(), 0);
        Assert.assertEquals(rover.getDirection(), "east");
    }


    //Test Rover move forward & backward 10 spots & turn left  - direction should change to West

    @Test
    public void testLeft() {
        rover.moveForward(5);
        rover.moveForward(5);
        rover.moveBackward(5);
        rover.moveBackward(5);
        rover.turnLeft();
        Assert.assertEquals(rover.getXCoordinate(), 0);
        Assert.assertEquals(rover.getYCoordinate(), 0);
        Assert.assertEquals(rover.getDirection(), "west");
    }


    //Test Emergency Transmitter invoked when the negative coordinates

    @Test
    public void testEmergencyTransmitter() {
        rover.moveForward(5); // y = 5
        rover.moveForward(5); // y = 10
        rover.moveBackward(10); //
        rover.moveBackward(10);
        //rover.turnLeft();
        Assert.assertEquals(rover.getXCoordinate(), 0);
        Assert.assertEquals(rover.getYCoordinate(), -10);
        Assert.assertEquals(rover.getDirection(), "North");
        verify(transmitter,times(1)).Transmit("Transmitting Emergency", 0, -10);


    }


   /* Rover moves forward 5 spots, turns right, forward 2 spots, turn right, forward 3 spots, turn left, backwards 1spots, turnsright.
    Coordinates should be 1,2; direction S */

    @Test
    public void testAllMovements() {
        rover.moveForward(5);
        rover.turnRight();
        rover.moveForward(2);
        rover.turnRight();
        rover.moveForward(3);
        rover.turnLeft();
        rover.moveBackward(1);
        rover.turnRight();

        Assert.assertEquals(rover.getXCoordinate(), 1);
        Assert.assertEquals(rover.getYCoordinate(), 2);
        Assert.assertEquals(rover.getDirection(), "south");
    }


}
