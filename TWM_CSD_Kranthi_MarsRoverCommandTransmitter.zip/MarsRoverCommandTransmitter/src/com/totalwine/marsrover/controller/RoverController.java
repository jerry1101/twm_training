package com.totalwine.marsrover.controller;

import com.totalwine.marsrover.model.Instruction;
import com.totalwine.marsrover.service.InstructionService;
import com.totalwine.marsrover.transmitter.EmergencyTransmitter;

public class RoverController {
	
	private static final String RIGHT = "Right";
	private static final String STRAIGHT = "straight";
	private static final String EAST = "East";
	private static final String SOUTH = "South";
	private static final String WEST = "West";
	private static final String NORTH = "North";
	
	InstructionService instructionService;
	EmergencyTransmitter emergencyTransmitter;
	Long guid;
	
	public RoverController(InstructionService instructionService, EmergencyTransmitter emergencyTransmitter) {
		this.instructionService = instructionService;
		this.emergencyTransmitter = emergencyTransmitter;
		this.guid = instructionService.saveInstruction(new Instruction()).getUid();
	}
	
	public void MoveForward(int spots) {
		Instruction instruction = instructionService.getInstruction(guid);
		Instruction updatedInstruction = instruction;
		updatedInstruction.setPreviousInstruction(getPreviousInstruction(instruction));
		updatedInstruction.setCurrentDirection(instruction.getCurrentDirection());  //North
		
		if(updatedInstruction.getCurrentDirection().equals(NORTH)) {
			updatedInstruction.setxCoordinate(instruction.getxCoordinate());
			updatedInstruction.setyCoordinate(instruction.getyCoordinate() + spots);
		}
		else if(updatedInstruction.getCurrentDirection().equals(WEST)) {
			updatedInstruction.setyCoordinate(instruction.getyCoordinate());
			updatedInstruction.setxCoordinate(instruction.getxCoordinate() - spots);
		}
		else if(updatedInstruction.getCurrentDirection().equals(SOUTH)) {
			updatedInstruction.setxCoordinate(instruction.getxCoordinate());
			updatedInstruction.setyCoordinate(instruction.getyCoordinate() - spots);
		}
		else if(updatedInstruction.getCurrentDirection().equals(EAST)) {
			updatedInstruction.setyCoordinate(instruction.getyCoordinate());
			updatedInstruction.setxCoordinate(instruction.getxCoordinate() + spots);
		}
		updatedInstruction.setFacingToward(STRAIGHT);
		updateInstructions(updatedInstruction);
	}



	public void MoveBackward(int spots) {
		Instruction instruction = instructionService.getInstruction(guid);
		Instruction updatedInstruction = instruction;
		updatedInstruction.setPreviousInstruction(getPreviousInstruction(instruction));
		updatedInstruction.setCurrentDirection(instruction.getCurrentDirection());  //North
		
		if(updatedInstruction.getCurrentDirection().equals(NORTH)) {
			updatedInstruction.setxCoordinate(instruction.getxCoordinate());
			updatedInstruction.setyCoordinate(instruction.getyCoordinate() - spots);
		}
		else if(updatedInstruction.getCurrentDirection().equals(WEST)) {
			updatedInstruction.setyCoordinate(instruction.getyCoordinate());
			updatedInstruction.setxCoordinate(instruction.getxCoordinate() + spots);
		}
		else if(updatedInstruction.getCurrentDirection().equals(SOUTH)) {
			updatedInstruction.setxCoordinate(instruction.getxCoordinate());
			updatedInstruction.setyCoordinate(instruction.getyCoordinate() + spots);
		}
		else if(updatedInstruction.getCurrentDirection().equals(EAST)) {
			updatedInstruction.setyCoordinate(instruction.getyCoordinate());
			updatedInstruction.setxCoordinate(instruction.getxCoordinate() - spots);
		}
		updatedInstruction.setFacingToward(STRAIGHT);
		updateInstructions(updatedInstruction);
	}
	
	
	public void TurnLeft() {
		Instruction instruction = instructionService.getInstruction(guid);
		Instruction updatedInstruction = instruction;
		updatedInstruction.setPreviousInstruction(getPreviousInstruction(instruction));
		
		if(instruction.getCurrentDirection().equals(NORTH)) {
			updatedInstruction.setCurrentDirection(WEST);
		}
		else if(instruction.getCurrentDirection().equals(EAST)) {
			updatedInstruction.setCurrentDirection(NORTH);
			
		}
		else if(instruction.getCurrentDirection().equals(SOUTH)) {
			updatedInstruction.setCurrentDirection(EAST);
		}
		else if(instruction.getCurrentDirection().equals(WEST)) {
			updatedInstruction.setCurrentDirection(SOUTH);
		}
		updatedInstruction.setFacingToward("Left");
		updateInstructions(updatedInstruction);
	}
	
	public void TurnRight() {
		
		Instruction instruction = instructionService.getInstruction(guid);
		Instruction updatedInstruction = instruction;
		updatedInstruction.setPreviousInstruction(getPreviousInstruction(instruction));
		
		if(instruction.getCurrentDirection().equals(NORTH)) {
			updatedInstruction.setCurrentDirection(EAST);
		}
		else if(instruction.getCurrentDirection().equals(EAST)) {
			updatedInstruction.setCurrentDirection(SOUTH);
			
		}
		else if(instruction.getCurrentDirection().equals(SOUTH)) {
			updatedInstruction.setCurrentDirection(WEST);
		}
		else if(instruction.getCurrentDirection().equals(WEST)) {
			updatedInstruction.setCurrentDirection(NORTH);
		}
		updatedInstruction.setFacingToward(RIGHT);
		updateInstructions(updatedInstruction);
	}
	
	public String GetDirection() {
		Instruction databaseRow = instructionService.getInstruction(this.guid);
		return databaseRow.getCurrentDirection();
		
	}
	
	public int GetXCoordinate() {
		Instruction databaseRow = instructionService.getInstruction(this.guid);
		return databaseRow.getxCoordinate();
		
	}
	
	public int GetYCoordinate() {
		Instruction databaseRow = instructionService.getInstruction(this.guid);
		return databaseRow.getyCoordinate();
		
	}
	
	private Instruction getPreviousInstruction(Instruction instruction) {
		return new Instruction(instruction.getUid(), instruction.getCurrentDirection(), instruction.getFacingToward(), instruction.getxCoordinate(), instruction.getyCoordinate(), instruction.getCurrentQuadrant(), null);
	}
	
	private void updateInstructions(Instruction instruction) {
		Instruction updatedInstruction = instructionService.updateInstruction(instruction);
		this.guid = updatedInstruction.getUid();
		if(updatedInstruction.getxCoordinate() < 0 || updatedInstruction.getyCoordinate() < 0) {
			String msg = "Emergency !!! warning!!!Rover wanders into Neverland";
			emergencyTransmitter.Transmit(msg, updatedInstruction.getxCoordinate(), updatedInstruction.getyCoordinate());
		}
		System.out.println(updatedInstruction);
	}

}
