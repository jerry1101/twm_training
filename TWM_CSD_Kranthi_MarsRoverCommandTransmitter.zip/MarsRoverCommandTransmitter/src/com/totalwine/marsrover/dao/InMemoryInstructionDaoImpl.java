package com.totalwine.marsrover.dao;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;

import com.totalwine.marsrover.model.Instruction;

import java.util.Set;

public class InMemoryInstructionDaoImpl implements InstructionDao {
	
	private static Map<Long, Instruction> instructionTable = new HashMap<Long, Instruction>();

	@Override
	public Instruction createInstruction(Instruction instruction) {
		instruction.setUid((long) instructionTable.size() + 1);
		instructionTable.put(instruction.getUid(), instruction);
		return instruction;
	}

	@Override
	public Instruction updateInstruction(Instruction instruction) {
		if (instruction.getUid() <= 0) {
			return new Instruction();
		}
		Instruction updatedInstruction = new Instruction(instruction.getUid(), instruction.getCurrentDirection(), instruction.getFacingToward(), instruction.getxCoordinate(), instruction.getyCoordinate(),
				instruction.getCurrentQuadrant(), instruction.getPreviousInstruction());
		instructionTable.put(updatedInstruction.getUid(), updatedInstruction);
		return updatedInstruction;
	}

	@Override
	public boolean deleteInsruction(long guid) {
		boolean find = false;

		if (guid <= 0) {
			return false;
		}
		Set<Entry<Long, Instruction>> set = instructionTable.entrySet();
		Iterator<Entry<Long, Instruction>> i = set.iterator();
		while (i.hasNext()) {
			Entry<Long, Instruction> me = i.next();
			if (me.getKey() == guid) {
				find = true;
				break;
			}
		}
		if (!find) {
			System.out.println("*****COULD NOT FIND ID IN A DATABASE*******");
			return false;
		} else {
			instructionTable.remove(guid);
			return true;
		}
	}

	@Override
	public List<Instruction> getAllInstructions() {
		return new ArrayList<Instruction>(instructionTable.values());
	}

	@Override
	public Instruction getInstruction(Long guid) {
		boolean find = false;

		if (guid <= 0) {
			return new Instruction();
		}

		Set<Entry<Long, Instruction>> set = instructionTable.entrySet();
		Iterator<Entry<Long, Instruction>> i = set.iterator();
		while (i.hasNext()) {
			Entry<Long, Instruction> me = i.next();
			if (me.getKey() == guid) {
				find = true;
				break;
			}
		}
		if (!find) {
			return new Instruction();
		} else {
			return instructionTable.get(guid);
		}
	}

}
