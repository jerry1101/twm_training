package com.totalwine.marsrover.dao;

public class SpringDataJPAInstructionDaoImpl implements InstructionDao {

	/**
	 * extend your own implementation using Spring Data JPA
	 */
}
