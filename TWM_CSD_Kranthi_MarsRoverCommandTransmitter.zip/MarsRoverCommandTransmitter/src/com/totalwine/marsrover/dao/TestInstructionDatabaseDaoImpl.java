package com.totalwine.marsrover.dao;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;

import com.totalwine.marsrover.model.Instruction;

import java.util.Set;

public class TestInstructionDatabaseDaoImpl implements InstructionDao {
	
	private static Map<Long, Instruction> testInstructionTable = new HashMap<Long, Instruction>();

	@Override
	public Instruction createInstruction(Instruction instruction) {
		instruction.setUid((long) testInstructionTable.size() + 1);
		testInstructionTable.put(instruction.getUid(), instruction);
		return instruction;
	}

	@Override
	public Instruction updateInstruction(Instruction instruction) {
		if (instruction.getUid() <= 0) {
			System.out.println("*****PLEASE ENTER CORRECT UID*******");
			return new Instruction();
		}
		Instruction updatedInstruction = new Instruction(instruction.getUid(), instruction.getCurrentDirection(), instruction.getFacingToward(), instruction.getxCoordinate(), instruction.getyCoordinate(),
				instruction.getCurrentQuadrant(), instruction.getPreviousInstruction());
		testInstructionTable.put(updatedInstruction.getUid(), updatedInstruction);
		return updatedInstruction;
	}

	@Override
	public boolean deleteInsruction(long guid) {
		boolean find = false;

		if (guid <= 0) {
			System.out.print("*****PLEASE ENTER CORRECT GUIID*******");
			return false;
		}
		Set<Entry<Long, Instruction>> set = testInstructionTable.entrySet();
		Iterator<Entry<Long, Instruction>> i = set.iterator();
		while (i.hasNext()) {
			Entry<Long, Instruction> me = i.next();
			if (me.getKey() == guid) {
				find = true;
				break;
			}
		}
		if (!find) {
			System.out.println("*****COULD NOT FIND ID IN A DATABASE*******");
			return false;
		} else {
			testInstructionTable.remove(guid);
			return true;
		}
	}

	@Override
	public List<Instruction> getAllInstructions() {
		return new ArrayList<Instruction>(testInstructionTable.values());
	}

	@Override
	public Instruction getInstruction(Long guid) {
		boolean find = false;

		if (guid <= 0) {
			System.out.println("*****PLEASE ENTER CORRECT ID*******");
			return new Instruction();
		}

		Set<Entry<Long, Instruction>> set = testInstructionTable.entrySet();
		Iterator<Entry<Long, Instruction>> i = set.iterator();
		while (i.hasNext()) {
			Entry<Long, Instruction> me = i.next();
			if (me.getKey() == guid) {
				find = true;
				break;
			}
		}
		if (!find) {
			System.out.println("*****COULD NOT FIND ID IN A DATABASE*******");
			return new Instruction();
		} else {
			return testInstructionTable.get(guid);
		}
	}

}
