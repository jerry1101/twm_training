package Rover;

public interface EmergencyTransmitter {
    public void transmit(String msg, int xCoordinate, int yCoordinate);
}