package Rover.impl;

import Rover.EmergencyTransmitter;

public class EmergencyTransmitterImpl implements EmergencyTransmitter {
    @Override
    public void transmit(String msg, int xCoordinate, int yCoordinate) {
            System.out.print(msg +", X coordinate is: " + xCoordinate + " y coordinate is: " +yCoordinate);
    }
}
