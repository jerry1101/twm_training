package Rover.impl;

import Rover.EmergencyTransmitter;
import Rover.Rover;

public class RoverImpl implements Rover {
    private int x;
    private int y;
    private String direction;
    private EmergencyTransmitter transmitter;

    public RoverImpl(int x, int y, String direction, EmergencyTransmitter transmitter){
        this.x = x;
        this.y =y;
        this.direction = direction;
        this.transmitter = transmitter;
    }

    public void moveForward(int spots) {
        if(direction.equalsIgnoreCase("n")){
            this.y += spots;
        }else if(direction.equalsIgnoreCase("s")){
            this.y -= spots;
        } else if(direction.equalsIgnoreCase("e")){
            this.x += spots;
        }else {
            this.x -= spots;
        }
        if(this.x < 0 || this.y <0 ){
            transmitter.transmit("SOS, System in distress", this.x, this.y);
        }
    }

    public void moveBackward(int spots) {
        if(direction.equalsIgnoreCase("n")) {
            this.y -= spots;
        }else if(direction.equalsIgnoreCase("s")) {
            this.y += spots;
        }else if(direction.equalsIgnoreCase("e")) {
            this.x -= spots;
        }else {
            this.x += spots;
        }
        if(this.x < 0 || this.y <0 ){
            transmitter.transmit("SOS, System in distress", this.x, this.y);
        }
    }

    public void turnLeft(){
        if(direction.equalsIgnoreCase("n")) {
            direction = "w";
        }else if(direction.equalsIgnoreCase("s")) {
            direction = "e";
        }else if(direction.equalsIgnoreCase("e")) {
            direction = "n";
        }else {
            direction = "s";
        }
    }

    public void turnRight(){
        if(direction.equalsIgnoreCase("n")) {
            direction = "e";
        }else if(direction.equalsIgnoreCase("s")) {
            direction = "w";
        }else if(direction.equalsIgnoreCase("e")) {
            direction = "s";
        }else {
            direction = "n";
        }
    }

    public String getDirection() {
        return this.direction;
    }

    public int getXCoordinate(){
        return this.x;
    }

    public int getYCoordinate() {
        return this.y;
    }
}
