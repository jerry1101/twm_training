package MarsRover;

public class EmergencyTransmitter implements IEmergencyTransmitter {
    public void Transmit(String msg, int xCoordinate, int yCoordinate)
    {
        //No implementation in scope of current feature
    };
}
