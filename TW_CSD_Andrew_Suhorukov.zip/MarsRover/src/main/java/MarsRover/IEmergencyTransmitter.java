package MarsRover;

public interface IEmergencyTransmitter {
    public void Transmit(String msg, int xCoordinate, int yCoordinate);
}
