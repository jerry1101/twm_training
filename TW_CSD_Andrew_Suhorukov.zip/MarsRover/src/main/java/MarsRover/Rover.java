package MarsRover;

public class Rover implements IRover {
    private IEmergencyTransmitter emergencyTransmitter;
    private int xCoordinate = 0;
    private int yCoordinate = 0;
    //private a
    private String direction = "North";

    public Rover(IEmergencyTransmitter emergencyTransmitter)
    {
        this.emergencyTransmitter = emergencyTransmitter;
    }

    private void MoveOneStep(int spots)
    {
        switch (direction)
        {
            case "North": yCoordinate+=spots;
                break;
            case "South": yCoordinate-=spots;
                break;
            case "East": xCoordinate+=spots;
                break;
            case "West": xCoordinate-=spots;
                break;
        }
        if (CheckNeverland()) {
            SendDistress();
        }
    }

    private boolean CheckNeverland()
    {
        return (xCoordinate < 0) ||(yCoordinate < 0) ;

    }

    private void SendDistress()
    {
        this.emergencyTransmitter.Transmit(direction,xCoordinate,yCoordinate);

    }

    public void MoveForward(int spots){
        MoveOneStep(spots);
    };
    public void MoveBackward(int spots){
        MoveOneStep(-spots);

    };
    public void TurnLeft(){
        switch (direction)
        {
            case "North": direction = "West";
                break;
            case "West": direction = "South";
                break;
            case "South": direction = "East";
                break;
            case "East": direction = "North";
                break;
        }

    };
    public void TurnRight(){

        switch (direction)
        {
            case "North": direction = "East";
                break;
            case "East": direction = "South";
                break;
            case "South": direction = "West";
                break;
            case "West": direction = "North";
                break;
        }
    };
    public String GetDirection(){
        return direction;
    };
    public int GetXCoordinate(){
        return xCoordinate;
    };
    public int GetYCoordinate(){
        return yCoordinate;
    };
}
