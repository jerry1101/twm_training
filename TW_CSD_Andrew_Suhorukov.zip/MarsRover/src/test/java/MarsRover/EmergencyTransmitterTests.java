package MarsRover;

import org.junit.Before;
import org.junit.Test;

import static org.junit.Assert.assertTrue;

public class EmergencyTransmitterTests {

    private IEmergencyTransmitter emergencyTransmitter;

    @Before
    public void beforeEach() {
        this.emergencyTransmitter = new EmergencyTransmitter();
    }

    @Test
    public void testTurnRight() {
        this.emergencyTransmitter.Transmit("",0,0);
        assertTrue(true);
    }


}
