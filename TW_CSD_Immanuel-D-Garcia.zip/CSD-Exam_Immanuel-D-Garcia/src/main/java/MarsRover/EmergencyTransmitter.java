package MarsRover;

public class EmergencyTransmitter {

    public static void Transmit(String msg, int xCoordinate, int yCoordinate) {
        System.out.println("Alert: your Rover is out of the safe zone!");
        System.out.println("Location: "+ xCoordinate + "," + yCoordinate + "Direction: " + msg);
        System.out.println("Please navigate back to 0,0");
    }

}
