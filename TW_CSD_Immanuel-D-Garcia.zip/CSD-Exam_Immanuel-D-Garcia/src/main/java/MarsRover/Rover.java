
package MarsRover;
import MarsRover.EmergencyTransmitter;

public class Rover {

    String msg;
    int xCoordinate = 0;
    int yCoordinate = 0;
    int direction = 0;
    String nav = "N";
    int spots = 0;
    int spin = 90;

    public void MoveForward(int spots, String nav) {
        if (nav == "N") {
            yCoordinate = yCoordinate + spots;
        } else if (nav == "E") {
            xCoordinate = xCoordinate + spots;
        } else if (nav == "S") {
            yCoordinate = yCoordinate - spots;
        } else {
            xCoordinate = xCoordinate - spots;
        }
        GetDirection();
    }

    public void MoveBackward(int spots, String nav) {
        if (nav == "N") {
            yCoordinate = yCoordinate - spots;
        } else if (nav == "E") {
            xCoordinate = xCoordinate - spots;
        } else if (nav == "S") {
            yCoordinate = yCoordinate + spots;
        } else {
            xCoordinate = xCoordinate + spots;
        }
        GetDirection();
    }

    public void TurnLeft() {
        if (direction > 0) {
            direction = direction - spin;
        } else direction = 270;
        GetDirection();
    }

    public void TurnRight() {
        if (direction == 270) {
            direction = 0;
        } else direction = direction + spin;
        GetDirection();
    }

    public String GetDirection() {

        //IDENTIFY X/Y AND EMERGENCY TRANSMIT IF EITHER X OR Y IS NEGATIVE
        if (xCoordinate < 0 || yCoordinate < 0)
            EmergencyTransmitter.Transmit(nav, xCoordinate, yCoordinate);

        // FIND NAVIGATION (N,E,S,W)
        if (direction == 0)
            nav = "N";
        else if (direction == 90)
            nav = "E";
        else if (direction == 180)
            nav = "S";
        else
            nav = "W";

        return nav;

    }

    public int GetXCoordinate() {
        if (xCoordinate < 0)
            EmergencyTransmitter.Transmit(nav, xCoordinate, yCoordinate);
        return xCoordinate;
    }

    public int GetXCoodrinate() {
        if (yCoordinate < 0)
            EmergencyTransmitter.Transmit(nav, xCoordinate, yCoordinate);
        return yCoordinate;
    }
}
