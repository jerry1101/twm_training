package Impl;

public class Constants {
    public static final String SOUTH = "South";
    public static final String WEST = "West";
    public static final String NORTH = "North";
    public static final String EAST = "East";
}
