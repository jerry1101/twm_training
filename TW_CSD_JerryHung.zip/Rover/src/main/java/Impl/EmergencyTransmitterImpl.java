package Impl;

import Interfice.EmergencyTransmitter;

public class EmergencyTransmitterImpl implements EmergencyTransmitter{

	@Override
	public void Transmit(String msg, int xCoordinate, int yCoordinate) {
		// TODO Auto-generated method stub
		
	}



}
