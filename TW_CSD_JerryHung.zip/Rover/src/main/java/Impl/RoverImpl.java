package Impl;

import Interfice.EmergencyTransmitter;
import Interfice.Rover;

public class RoverImpl implements Rover {

    private int x;
    private int y;
    private String direction;
    private EmergencyTransmitterImpl transmitter;

    public RoverImpl(String existingDirection){
        this.transmitter = new EmergencyTransmitterImpl();
        this.direction = existingDirection;
        int x = 0;
        int y = 0;
    }

    @Override
    public void moveForward(int spots) {
        assert spots >0;
        if (direction.equalsIgnoreCase(Constants.NORTH)) {
            y += spots;
        } else if (direction.equalsIgnoreCase(Constants.SOUTH)) {
            y -= spots;
        } else if (direction.equalsIgnoreCase(Constants.EAST)) {
            x += spots;
        } else {
            x -= spots;
        }
        transmitter.Transmit("moveForward is done",x,y);
    }

    @Override
    public void moveBackward(int spots) {
        assert spots >0;
        if (direction.equalsIgnoreCase(Constants.NORTH)) {
            y -= spots;
        } else if (direction.equalsIgnoreCase(Constants.SOUTH)) {
            y += spots;
        } else if (direction.equalsIgnoreCase(Constants.EAST)) {
            x -= spots;
        } else {
            x += spots;
        }
        transmitter.Transmit("moveBackward is done",x,y);
    }

    @Override
    public void turnLeft() {
        if (direction.equalsIgnoreCase(Constants.NORTH)) {
            direction = Constants.WEST;
        } else if (direction.equalsIgnoreCase(Constants.WEST)) {
            direction = Constants.SOUTH;
        } else if (direction.equalsIgnoreCase(Constants.SOUTH)) {
            direction = Constants.EAST;
        } else {
            direction = Constants.NORTH;
        }

    }

    @Override
    public void turnRight() {
        if (direction.equalsIgnoreCase(Constants.NORTH)) {
            direction = Constants.EAST;
        } else if (direction.equalsIgnoreCase(Constants.EAST)) {
            direction = Constants.SOUTH;
        } else if (direction.equalsIgnoreCase(Constants.SOUTH)) {
            direction = Constants.WEST;
        } else {
            direction = Constants.NORTH;
        }

    }

    @Override
    public String getDirection() {
        return direction;
    }

    @Override
    public int getXCoordinate() {
        return x;
    }

    @Override
    public int getYCoordinate() {
        return y;
    }

    private void sendMessage(String msg, int xCoordinate, int yCoordinate)
    {

        transmitter.Transmit(msg,xCoordinate,yCoordinate);
    }

}
