package Interfice;

public interface EmergencyTransmitter {

    public void Transmit(String msg, int xCoordinate, int yCoordinate);
}
