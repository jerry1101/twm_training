package MarsRoverTest;

import Impl.Constants;
import Impl.EmergencyTransmitterImpl;
import Interfice.EmergencyTransmitter;
import org.junit.Assert;
import org.junit.Test;

import static org.mockito.Mockito.*;

import Interfice.Rover;
import Impl.RoverImpl;

import static org.mockito.Mockito.mock;

public class RoverTest {

    @Test
    public void testMoveforward() {

        Rover rover = new RoverImpl(Constants.NORTH);

        rover.moveForward(5);
        var finalDirection = rover.getDirection();
        var xCoordinate = rover.getXCoordinate();
        var yCoordinate = rover.getYCoordinate();
        Assert.assertEquals("North", finalDirection);
        Assert.assertEquals(0, xCoordinate);
        Assert.assertEquals(5, yCoordinate);


    }

    @Test
    public void testMoveforwardAndTurnRight() {

        Rover rover = new RoverImpl(Constants.NORTH);

        rover.moveForward(5);
        rover.turnRight();
        var finalDirection = rover.getDirection();
        var xCoordinate = rover.getXCoordinate();
        var yCoordinate = rover.getYCoordinate();
        Assert.assertEquals(Constants.EAST, finalDirection);
        Assert.assertEquals(0, xCoordinate);
        Assert.assertEquals(5, yCoordinate);


    }
    @Test
    public void testRover() {

        Rover rover = new RoverImpl(Constants.NORTH);

        rover.moveForward(5);
        rover.turnRight();
        rover.moveForward(2);
        rover.turnRight();
        rover.moveForward(3);
        rover.turnLeft();
        rover.moveBackward(1);
        rover.turnRight();
        var finalDirection = rover.getDirection();
        var xCoordinate = rover.getXCoordinate();
        var yCoordinate = rover.getYCoordinate();
        Assert.assertEquals(Constants.SOUTH, finalDirection);
        Assert.assertEquals(1, xCoordinate);
        Assert.assertEquals(2, yCoordinate);


    }

    @Test
    public void testMessageTransmit() {
        EmergencyTransmitter transmitter = mock(EmergencyTransmitter.class);
        Rover rover = new RoverImpl(Constants.NORTH);
        rover.moveBackward(5);
        verify(transmitter, times(1));


    }

    @Test
    public void testMessageTransmitWithSpy() {
        EmergencyTransmitter transmitter = spy(new EmergencyTransmitterImpl());
        doCallRealMethod().when(transmitter).Transmit(anyString(),anyInt(),anyInt());

        Rover rover = new RoverImpl(Constants.NORTH);
        rover.moveBackward(5);
        verify(transmitter, times(1));


    }

	@Test(expected = AssertionError.class)
    public void testMoldboardWithNegative() {
        Rover rover = new RoverImpl(Constants.NORTH);
        rover.moveForward(-5);



    }

    @Test(expected = AssertionError.class)
    public void testMoveBackwardWithNegative() {
        Rover rover = new RoverImpl(Constants.NORTH);
        rover.moveBackward(-5);



    }
}
