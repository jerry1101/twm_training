package marsRoverImps;

import marsRover.EmergencyTransmitter;

public class EmergencyTransmitterImps implements EmergencyTransmitter{

	@Override
	public void Transmit(String msg, int xCoordinate, int yCoordinate) {
		if (xCoordinate<0 || yCoordinate<0) {
			System.out.print("Transmiting Signal to Home. X = "+xCoordinate+". Y = "+ yCoordinate);
		}

		
	}



}
