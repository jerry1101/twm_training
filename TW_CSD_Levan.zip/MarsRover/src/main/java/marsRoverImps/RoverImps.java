package marsRoverImps;

import marsRover.Rover;

public class RoverImps implements Rover {

	private int x = 0;
	private int y = 0;
	private String facing = "N";

	EmergencyTransmitterImps Emergency = new EmergencyTransmitterImps();
	
	/**
	 * this methods will validate if spot >= 0 and move # of times forward or backward
	 */
	@Override
	public void MoveForward(int spots) {
		if (spots < 0) {
		throw new IllegalArgumentException(
		"Negative point will switch the move backwards. Spot must be more than 0");
		}
		if (facing.equals("N")) {
			y += spots;
		} else if (facing.equals("S")) {
			y -= spots;
		} else if (facing.equals("E")) {
			x += spots;
		} else {
			x -= spots;
		}
		Emergency.Transmit("", x, y);
		}

	@Override
	public void MoveBackward(int spots) {
		if (spots < 0) {
			throw new IllegalArgumentException(
			"Negative point will switch the move backwards. Spot must be more than 0");
			}
		if (facing.equals("N")) {
			y -= spots;
		} else if (facing.equals("S")) {
			y += spots;
		} else if (facing.equals("E")) {
			x -= spots;
		} else {
			x += spots;
		}
		Emergency.Transmit("", x, y);
		}

	/**
	 * this methods will change orientation to the Left or Right
	 */
	@Override
	public void TurnLeft() {
		if (facing.equals("N")) {
			facing = "W";
		} else if (facing.equals("W")) {
			facing = "S";
		} else if (facing.equals("S")) {
			facing = "E";
		} else {
			facing = "N";
		}
	}

	@Override
	public void TurnRight() {
		if (facing.equals("N")) {
			facing = "E";
		} else if (facing.equals("E")) {
			facing = "S";
		} else if (facing.equals("S")) {
			facing = "W";
		} else {
			facing = "N";
		}
	}

	
	@Override
	public String GetDirection() {
		return facing;
	}

	@Override
	public int GetXCoordinate() {
		return x;
	}

	@Override
	public int GetYCoordinate() {
		return y;
	}

}
