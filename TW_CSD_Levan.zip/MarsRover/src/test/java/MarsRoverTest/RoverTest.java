package MarsRoverTest;

import java.io.ByteArrayOutputStream;
import java.io.PrintStream;

import org.junit.After;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Ignore;
import org.junit.Test;

import marsRover.Rover;
import marsRoverImps.EmergencyTransmitterImps;
import marsRoverImps.RoverImps;

	public class RoverTest {

	Rover Rover = new RoverImps();
	
	private final ByteArrayOutputStream outContent = new ByteArrayOutputStream();
    private final PrintStream originalOut = System.out;

    @Before
    public void before(){
        System.setOut(new PrintStream(outContent));
    }
    @After
    public void restoreStreams() {
        System.setOut(originalOut);
    }
	
		
//	@Ignore
	@Test //Test default spot value
	public void testRoverDefaultPoint() {
		System.out.println("x = "+Rover.GetXCoordinate()+". y = "+Rover.GetYCoordinate()+". Direction = "+Rover.GetDirection());
		Assert.assertEquals(Rover.GetXCoordinate(), 0);
		Assert.assertEquals(Rover.GetYCoordinate(), 0);
		Assert.assertEquals(Rover.GetDirection(), "N");
	}
	
//	@Ignore
	@Test //Test zero spot value 
	public void testRoverZeroSpots() {
		Rover.MoveForward(0);
		Rover.MoveBackward(0);
		Assert.assertEquals(Rover.GetXCoordinate(), 0);
		Assert.assertEquals(Rover.GetYCoordinate(), 0);
		Assert.assertEquals(Rover.GetDirection(), "N");
		System.out.println("x = "+Rover.GetXCoordinate()+". y = "+Rover.GetYCoordinate()+". Direction = "+Rover.GetDirection());
	}
	
//	@Ignore
	@Test //Test negative spot value
	(expected = IllegalArgumentException.class)
	public void testRoverNegativeSpots() {
		Rover.MoveForward(-2);
		Rover.MoveBackward(-001);
		System.out.println("x = "+Rover.GetXCoordinate()+". y = "+Rover.GetYCoordinate()+". Direction = "+Rover.GetDirection());
	}
	
//	@Ignore
	@Test //Test left and right turns
	public void testRoverTurns() {
		System.out.println("Current Orientation = "+Rover.GetDirection());
		Rover.TurnLeft();
		Assert.assertEquals(Rover.GetDirection(), "W");
		System.out.println("90� Left from Current = "+Rover.GetDirection());
		Rover.TurnRight();
		Assert.assertEquals(Rover.GetDirection(), "N");
		System.out.println("90� Right from Current = "+Rover.GetDirection());
		Rover.TurnRight();
		Assert.assertEquals(Rover.GetDirection(), "E");
		System.out.println("90� Right from Current = "+Rover.GetDirection());
		Rover.TurnRight();
		Assert.assertEquals(Rover.GetDirection(), "S");
		System.out.println("90� Right from Current = "+Rover.GetDirection());
	}
	
//	@Ignore
	@Test //Test Coordinates  x1, y2; direction-S 
	public void testRoverCoordinations() {
		Rover.MoveForward(5);
		System.out.println("x = "+Rover.GetXCoordinate()+". y = "+Rover.GetYCoordinate()+". Direction = "+Rover.GetDirection());
		Assert.assertEquals(Rover.GetYCoordinate(), 5);
		Rover.TurnRight();
		Rover.MoveForward(2);
		System.out.println("x = "+Rover.GetXCoordinate()+". y = "+Rover.GetYCoordinate()+". Direction = "+Rover.GetDirection());
		Assert.assertEquals(Rover.GetXCoordinate(), 2);
		Rover.TurnRight();
		Rover.MoveForward(3);
		System.out.println("x = "+Rover.GetXCoordinate()+". y = "+Rover.GetYCoordinate()+". Direction = "+Rover.GetDirection());
		Assert.assertEquals(Rover.GetYCoordinate(), 2);
		Rover.TurnLeft();
		Rover.MoveBackward(1);
		System.out.println("x = "+Rover.GetXCoordinate()+". y = "+Rover.GetYCoordinate()+". Direction = "+Rover.GetDirection());
		Assert.assertEquals(Rover.GetXCoordinate(), 1);
		Rover.TurnRight();
		System.out.println("*******Required Result*******  x = "+Rover.GetXCoordinate()+". y = "+Rover.GetYCoordinate()+". Direction = "+Rover.GetDirection());
	}
	
//	@Ignore
	@Test //Test Emergency Transmitter in case x or y is less than 0
	public void testRoverEmergencyTransmiter() {
		Rover.MoveBackward(1);
		Assert.assertEquals(Rover.GetYCoordinate(), -1);
		Assert.assertEquals("Transmiting Signal to Home. X = 0. Y = -1", outContent.toString());
		Rover.TurnLeft();
		Rover.MoveForward(1);
		Assert.assertEquals((Rover.GetXCoordinate() & Rover.GetYCoordinate()), -1);
		Assert.assertTrue(outContent.toString().contains("Transmiting Signal to Home. X = -1. Y = -1"));
		Rover.TurnRight();
		Rover.MoveForward(1);
		Assert.assertEquals(Rover.GetXCoordinate(), -1);
		Assert.assertTrue(outContent.toString().contains("Transmiting Signal to Home. X = -1. Y = 0"));

	}
	
//	@Ignore
	@Test //Test Emergency Transmitter in not called when not x & y >= 0
	public void testRoverTransmitterOff() {
		Rover.MoveForward(1);	
		Assert.assertTrue(outContent.toString().isEmpty());
	}
	
	
	
	
}
