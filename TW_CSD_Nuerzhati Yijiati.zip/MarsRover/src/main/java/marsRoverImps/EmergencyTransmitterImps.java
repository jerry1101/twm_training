package marsRoverImps;

import marsRover.EmergencyTransmitter;

public class EmergencyTransmitterImps implements EmergencyTransmitter{

	@Override
	public void Transmit(String msg, int xCoordinate, int yCoordinate) {

		if(xCoordinate<0 || yCoordinate<0) {
			System.out.println("Caution: we are on Neverland! "+msg+"\n");
			throw new IllegalArgumentException("We are in NeverLand!");
					
			
		}
		
		
	}



}
