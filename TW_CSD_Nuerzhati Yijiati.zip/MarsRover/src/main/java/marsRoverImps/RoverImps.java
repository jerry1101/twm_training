package marsRoverImps;

import marsRover.Rover;

public class RoverImps implements Rover {

	private int x = 0;
	private int y = 0;
	private String facing = "north";
	private EmergencyTransmitterImps ET = new EmergencyTransmitterImps();

	@Override
	public void MoveForward(int spots) {
		if (facing.equalsIgnoreCase("north")) {
			y += spots;
		} else if (facing.equalsIgnoreCase("South")) {
			y -= spots;
		} else if (facing.equalsIgnoreCase("east")) {
			x += spots;
		} else {
			x -= spots;
		}
		ET.Transmit("Mayday! Mayday!", x, y);
	}

	@Override
	public void MoveBackward(int spots) {
		if (facing.equalsIgnoreCase("north")) {
			y -= spots;
		} else if (facing.equalsIgnoreCase("South")) {
			y += spots;
		} else if (facing.equalsIgnoreCase("east")) {
			x -= spots;
		} else {
			x += spots;
		}
		ET.Transmit("Mayday! Mayday!", x, y);
	}

	@Override
	public void TurnLeft() {
		if (facing.equalsIgnoreCase("north")) {
			facing = "west";
		} else if (facing.equalsIgnoreCase("west")) {
			facing = "south";
		} else if (facing.equalsIgnoreCase("south")) {
			facing = "east";
		} else {
			facing = "north";
		}

	}

	@Override
	public void TurnRight() {
		if (facing.equalsIgnoreCase("north")) {
			facing = "east";
		} else if (facing.equalsIgnoreCase("east")) {
			facing = "south";
		} else if (facing.equalsIgnoreCase("south")) {
			facing = "west";
		} else {
			facing = "north";
		}

	}

	@Override
	public String GetDirection() {
		return facing;
	}

	@Override
	public int GetXCoordinate() {
		return x;
	}

	@Override
	public int GetYCoordinate() {
		return y;
	}

}
