package MarsRoverTest;

import org.junit.Assert;
import org.junit.Test;

import marsRover.Rover;
import marsRoverImps.RoverImps;

public class RoverTest {
	
	@Test
	public void moveForwardXTest() {
		Rover rover = new RoverImps();
		rover.MoveForward(5);
		Assert.assertTrue("Y has wrong vlaue!", rover.GetYCoordinate() == 5);
		
	}
	
	@Test
	public void moveForwardYTest() {
		Rover rover = new RoverImps();
		rover.TurnRight();
		rover.MoveForward(5);
		Assert.assertTrue("Y has wrong vlaue!", rover.GetXCoordinate() == 5);
	}
	
	@Test
	public void turnRightTest() {
		Rover rover = new RoverImps();
		rover.TurnRight();
		Assert.assertTrue("Position is not correct!", rover.GetDirection().equals("east"));
	}
	@Test
	public void turnLeftTest() {
		Rover rover = new RoverImps();
		rover.TurnLeft();
		Assert.assertTrue("Position is not correct!", rover.GetDirection().equals("west"));
	}
	@Test
	public void turnTest() {
		Rover rover = new RoverImps();
		rover.TurnRight();
		rover.MoveForward(1);
		rover.TurnLeft();
		rover.TurnLeft();
		Assert.assertTrue("Position is not correct!", rover.GetDirection().equals("west"));
	}
	
	
	@Test
	public void moveBackwardTest() {
		Rover rover = new RoverImps();
		rover.MoveForward(3);
		rover.TurnRight();
		rover.MoveForward(5);
		rover.TurnLeft();
		rover.MoveBackward(2);
		Assert.assertTrue("X has wrong value!", rover.GetXCoordinate() == 5);
		Assert.assertTrue("Y has wrong vlaue!", rover.GetYCoordinate() == 1);
		Assert.assertTrue("Position is not correct!", rover.GetDirection().equals("north"));
		
	}
	
	@Test(expected=IllegalArgumentException.class)
	public void moveBackwardYNegativeTest() {
		Rover rover = new RoverImps();
		rover.MoveBackward(5);
		
	}
	
	@Test(expected=IllegalArgumentException.class)
	public void moveBackwardXNegativeTest() {
		Rover rover = new RoverImps();
		rover.TurnRight();
		rover.MoveBackward(5);
		
	}
	
	
	@Test(expected=IllegalArgumentException.class)
	public void negativeTest() {
		Rover rover = new RoverImps();
		rover.TurnLeft();
		rover.TurnLeft();
		rover.MoveForward(5);
		System.out.println("x is: " + rover.GetXCoordinate() + " , y is: " + rover.GetYCoordinate() + "\n");
	}
	

	@Test
	public void testRover() {
		Rover rover = new RoverImps();
		rover.MoveForward(5);
		rover.TurnRight();
		rover.MoveForward(2);
		rover.TurnRight();
		rover.MoveForward(3);
		rover.TurnLeft();
		rover.MoveBackward(1);
		rover.TurnRight();

		System.out.println("x is: " + rover.GetXCoordinate() + " , y is: " + rover.GetYCoordinate());
		System.out.println("positon is " + rover.GetDirection() + "\n");
		Assert.assertTrue("X has wrong value!", rover.GetXCoordinate() == 1);
		Assert.assertTrue("Y has wrong vlaue!", rover.GetYCoordinate() == 2);
		Assert.assertTrue("Position is not correct!", rover.GetDirection().equals("south"));

	}

	@Test
	public void testRover2() {
		Rover rover = new RoverImps();
		rover.MoveForward(5);
		rover.TurnRight();
		rover.MoveForward(2);
		rover.MoveForward(3);
		rover.TurnLeft();
		rover.MoveBackward(1);
		rover.TurnRight();
		rover.TurnLeft();
		rover.MoveBackward(1);
		rover.TurnRight();

		System.out.println("x is: " + rover.GetXCoordinate() + " , y is: " + rover.GetYCoordinate());
		System.out.println("positon is " + rover.GetDirection() + "\n");
		Assert.assertTrue("X has wrong value!", rover.GetXCoordinate() == 5);
		Assert.assertTrue("Y has wrong vlaue!", rover.GetYCoordinate() == 3);
		Assert.assertTrue("Position is not correct!", rover.GetDirection().equals("east"));

	}


}
