package rover.impl;

import rover.EmergencyTransmitter;

public class EmergencyTransmitterImpl implements EmergencyTransmitter {

    @Override
    public void transmit(String msg, int xCoordinate, int yCoordinate) {
        System.out.print(msg +  xCoordinate + "," + yCoordinate);
    }
}
