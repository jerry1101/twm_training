package rover.impl;

import rover.EmergencyTransmitter;
import rover.Rover;

public class RoverImpl implements Rover {

    private String direction;
    private int xCoordinate;
    private int yCoordinate;

    private EmergencyTransmitter emergencyTransmitter;

    // Constructor to set default values
    public RoverImpl(EmergencyTransmitter emergencyTransmitter) {
        this.emergencyTransmitter = emergencyTransmitter;
        this.direction = "North";
        this.xCoordinate = 0;
        this.yCoordinate = 0;
    }

    @Override
    public void moveForward(int spots) {

        // If facing north ...
        if (this.direction.equalsIgnoreCase("North")) {
            // ... moveForward by incrementing yCoordinate
            this.yCoordinate++;
        }

        // If facing south ...
        else if (this.direction.equalsIgnoreCase("South")) {
            this.yCoordinate--;
        }

        // else if facing east ...
        else if (this.direction.equalsIgnoreCase("East")) {
            // ... moveForward by incrementing xCoordinate
            this.xCoordinate++;
        }

        // else if facing east ...
        else if (this.direction.equalsIgnoreCase("West")) {
            this.xCoordinate--;
        }

        if (this.xCoordinate < 0 || this.yCoordinate < 0) {
            emergencyTransmitter.transmit("I am stuck at ", this.xCoordinate, this.yCoordinate);
        }

    }

    @Override
    public void moveBackward(int spots) {

        // If facing North ...
        if (this.direction.equalsIgnoreCase("North")) {
            this.yCoordinate--;
        }

        // else if facing South ...
        else if (this.direction.equalsIgnoreCase("South")) {
            this.yCoordinate++;
        }

        // else if facing East ...
        else if (this.direction.equalsIgnoreCase("East")) {
            this.xCoordinate--;
        }

        // else if facing West ...
        else if (this.direction.equalsIgnoreCase("West")) {
            this.xCoordinate++;
        }

        if (this.xCoordinate < 0 || this.yCoordinate < 0) {
            emergencyTransmitter.transmit("I am stuck at ", this.xCoordinate, this.yCoordinate);
        }

    }

    @Override
    public void turnLeft() {

        // If facing North ...
        if (this.direction.equalsIgnoreCase("North")) {
            // ... turn to the west
            this.direction = "West";
        }

        // If facing South ...
        else if (this.direction.equalsIgnoreCase("South")) {
            // ... turn to the east
            this.direction = "East";
        }

        // If facing East ...
        else if (this.direction.equalsIgnoreCase("East")) {
            // ... turn to the north
            this.direction = "North";
        }

        // If facing West ...
        else if (this.direction.equalsIgnoreCase( "West")) {
            // ... turn to the south
            this.direction = "South";
        }

    }

    @Override
    public void turnRight() {

        // If facing North ...
        if (this.direction.equalsIgnoreCase("North")) {
            // ... turn to the east
            this.direction = "East";
        }

        // else if facing South ...
        else if (this.direction.equalsIgnoreCase("South")) {
            // ... turn to the west
            this.direction = "West";
        }

        // else if facing East ...
        else if (this.direction.equalsIgnoreCase("East")) {
            // ... turn to the south
            this.direction = "South";
        }

        // else if facing West ...
        else if (this.direction.equalsIgnoreCase("West")) {
            // ... turn to the north
            this.direction = "North";
        }
    }

    @Override
    public String getDirection() {
        return direction;
    }

    @Override
    public int getXCoordinate() {
        return  xCoordinate;
    }

    @Override
    public int getYCoordinate() {
        return yCoordinate;
    }
}
