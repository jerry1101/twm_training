package rover;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import rover.impl.EmergencyTransmitterImpl;

import java.io.ByteArrayOutputStream;
import java.io.PrintStream;

import static org.junit.Assert.*;

public class EmergencyTransmitterImplTests {

    private EmergencyTransmitter emergencyTransmitter;

    private final ByteArrayOutputStream outputStream = new ByteArrayOutputStream();
    private final PrintStream originalOut = System.out;

    @Before
    public void setUp() {
        System.setOut(new PrintStream(outputStream));
        emergencyTransmitter = new EmergencyTransmitterImpl();
    }

    @After
    public void restoreStream() {
        System.setOut(originalOut);
    }

    @Test
    public void testTransmit() {
        emergencyTransmitter.transmit("I am stuck at ", -1, 0);
        assertEquals("I am stuck at -1,0", outputStream.toString());
    }


}
