package rover.integration;

import org.junit.Before;
import org.junit.Test;
import rover.EmergencyTransmitter;
import rover.Rover;
import rover.impl.RoverImpl;

import static org.mockito.Mockito.mock;

public class RoverImpTests {

    private Rover classUnderTest;
    private EmergencyTransmitter emergencyTransmitter;

//    @Test
//    public void testNegativeXCoordinateTransmitMessage() {
//        emergencyTransmitter = mock(EmergencyTransmitter.class);
//        classUnderTest = new RoverImpl(emergencyTransmitter);
//
//        classUnderTest.moveBackward(1);
//        if (classUnderTest.getYCoordinate() < 0) {
//            emergencyTransmitter.Transmit();
//        }
//    }
}
