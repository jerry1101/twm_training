package marsRover;

public class EmergencyTransmitter {
    public void transmit(String msg, int xCoordinate, int yCoordinate){
        System.out.print(msg);
    }
}
