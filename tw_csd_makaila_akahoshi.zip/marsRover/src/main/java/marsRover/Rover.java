package marsRover;

import marsRover.RoverMoving;
import marsRover.RoverTurning;

public class Rover implements RoverMoving, RoverTurning {
     private int x;
     private int y;
     private String direction;
     EmergencyTransmitter emergencyTransmitter;

    public Rover (int x, int y, String direction, EmergencyTransmitter emergencyTransmitter) {
        this.x = x;
        this.y = y;
        this.direction = direction;
        this.emergencyTransmitter = emergencyTransmitter;
    }

    //Move calls expect the number of spaces to move
    public void moveForward(int spots) {
        if (this.direction == "N") {
            this.y = this.y + spots;
        }
        else if (this.direction == "E") {
            this.x = this.x + spots;
        }
        else if (this.direction == "S"){
            this.y = this.y - spots;
        }
        else if (this.direction == "W"){
            this.x = this.x - spots;
        }
        if (this.x < 0 || this.y < 0){
            this.emergencyTransmitter.transmit("out of range - send distress satellite transmission signal",this.x, this.y);
        }
    }

    //Move calls expect the number of spaces to move
    public void moveBackward(int spots){
        if (this.direction == "N") {
            this.y = this.y - spots;
        }
        else if (this.direction == "E") {
            this.x = this.x - spots;
        }
        else if (this.direction == "S"){
            this.y = this.y + spots;
        }
        else if (this.direction == "W"){
            this.x = this.x + spots;
        }
        if (this.x < 0 || this.y < 0){
            this.emergencyTransmitter.transmit("out of range - send distress satellite transmission signal",this.x, this.y);
        }
    }

    //Turn calls assume a 90 degree turn.
    public void turnLeft(){
        if (this.direction == "N") {
            this.direction = "W";
        }
        else if (this.direction == "E") {
            this.direction = "N";
        }
        else if (this.direction == "S") {
            this.direction = "E";
        }
        else if (this.direction == "W") {
            this.direction = "S";
        }
    }

    //Turn calls assume a 90 degree turn.
    public void turnRight(){
        if (this.direction == "N"){
            this.direction = "E";
        }
        else if (this.direction == "E"){
            this.direction = "S";
        }
        else if (this.direction == "S"){
            this.direction = "W";
        }
        else if (this.direction == "W"){
            this.direction = "N";
        }
    }

    //Rover is facing North in the beginning
    public String getDirection(){
       return this.direction;
    }

    public int getXCoordinate(){
        return this.x;
    }

    public int getYCoordinate(){
        return this.y;
    }
}