package marsRover;

public interface RoverMoving {
    void moveForward(int spots);
    void moveBackward(int spots);
}
