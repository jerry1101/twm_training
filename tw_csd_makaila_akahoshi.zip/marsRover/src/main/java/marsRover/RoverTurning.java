package marsRover;

public interface RoverTurning {
    void turnLeft();
    void turnRight();
}
