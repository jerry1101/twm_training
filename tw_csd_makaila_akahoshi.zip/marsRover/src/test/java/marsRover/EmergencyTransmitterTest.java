package marsRover;

import org.junit.*;
import static org.junit.Assert.*;
import java.io.ByteArrayOutputStream;
import java.io.PrintStream;

public class EmergencyTransmitterTest {
    private EmergencyTransmitter emergencyTransmitter;
    private final ByteArrayOutputStream outContent = new ByteArrayOutputStream();
    private final PrintStream originalOut = System.out;

    @Before
    public void initializeEmergencyTransmitter() {
        emergencyTransmitter = new EmergencyTransmitter();
        System.setOut(new PrintStream(outContent));
    }

    @Test
    public void testMessageWasTransmitted() {
        emergencyTransmitter.transmit("out of range - send distress satellite transmission signal", -2, 5);
        assertEquals("out of range - send distress satellite transmission signal", outContent.toString());
    }

    @After
    public void restoreStreams() {
        System.setOut(originalOut);
    }
}