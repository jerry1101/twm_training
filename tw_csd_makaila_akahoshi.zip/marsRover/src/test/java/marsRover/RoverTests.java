package marsRover;

import org.junit.*;
import static org.junit.Assert.*;
import static org.mockito.Mockito.*;
import org.mockito.Mock;

public class RoverTests {
    private Rover roverAtOrigin;
    private Rover southFacingRoverAtThirdQuadrant;

    @Mock
    private EmergencyTransmitter transmitter;

    @Before
    public void initialize() {
        transmitter = mock(EmergencyTransmitter.class);
        roverAtOrigin = new Rover(0,0,"N",transmitter);
        southFacingRoverAtThirdQuadrant = new Rover(-3,-2,"S",transmitter);
    }

    @Test
    public void testInitialLocationOfRovers() {
        assertEquals(roverAtOrigin.getDirection(), "N");
        assertEquals(roverAtOrigin.getXCoordinate(), 0);
        assertEquals(roverAtOrigin.getYCoordinate(), 0);
        assertEquals(southFacingRoverAtThirdQuadrant.getDirection(), "S");
        assertEquals(southFacingRoverAtThirdQuadrant.getXCoordinate(), -3);
        assertEquals(southFacingRoverAtThirdQuadrant.getYCoordinate(), -2);
    }

    @Test
    public void testDirectionIsNotNull() {
        assertNotNull(roverAtOrigin.getDirection());
        assertNotNull(southFacingRoverAtThirdQuadrant.getDirection());
    }

    @Test
    public void testXCoordinateIsNotNull() {
        assertNotNull(roverAtOrigin.getXCoordinate());
        assertNotNull(southFacingRoverAtThirdQuadrant.getXCoordinate());
    }

    @Test
    public void testYCoordinateIsNotNull() {
        assertNotNull(roverAtOrigin.getYCoordinate());
        assertNotNull(southFacingRoverAtThirdQuadrant.getYCoordinate());
    }

    @Test
    public void testWhenPositiveValueIsPassedToMoveForward() {
        roverAtOrigin.moveForward(5);
        southFacingRoverAtThirdQuadrant.moveForward(1);
        assertEquals(roverAtOrigin.getYCoordinate(), 5);
        assertEquals(southFacingRoverAtThirdQuadrant.getYCoordinate(), -3);
    }

    @Test
    public void testWhenZeroIsPassedToMoveForward() {
        int initialCoordinateOfRoverAtOrigin = roverAtOrigin.getYCoordinate();
        int initialCoordinateOfSouthFacingRoverAtThirdQuadrant = southFacingRoverAtThirdQuadrant.getYCoordinate();
        roverAtOrigin.moveForward(0);
        southFacingRoverAtThirdQuadrant.moveForward(0);
        assertEquals(roverAtOrigin.getYCoordinate(), initialCoordinateOfRoverAtOrigin);
        assertEquals(southFacingRoverAtThirdQuadrant.getYCoordinate(), initialCoordinateOfSouthFacingRoverAtThirdQuadrant);
    }

    @Test
    public void testWhenNegativeValueIsPassedToMoveForward() {
        roverAtOrigin.moveForward(-5);
        southFacingRoverAtThirdQuadrant.moveForward(-1);
        assertEquals(roverAtOrigin.getYCoordinate(), -5);
        assertEquals(southFacingRoverAtThirdQuadrant.getYCoordinate(), -1);
    }

    @Test
    public void testWhenRoverMovesBackward() {
        roverAtOrigin.moveBackward(5);
        southFacingRoverAtThirdQuadrant.moveBackward(1);
        assertEquals(roverAtOrigin.getYCoordinate(), -5);
        assertEquals(southFacingRoverAtThirdQuadrant.getYCoordinate(), -1);
    }

    @Test
    public void testWhenZeroIsPassedToMoveBackward() {
        int initialCoordinateOfRoverAtOrigin = roverAtOrigin.getYCoordinate();
        int initialCoordinateOfSouthFacingRoverAtThirdQuadrant = southFacingRoverAtThirdQuadrant.getYCoordinate();
        roverAtOrigin.moveBackward(0);
        southFacingRoverAtThirdQuadrant.moveBackward(0);
        assertEquals(roverAtOrigin.getYCoordinate(), initialCoordinateOfRoverAtOrigin);
        assertEquals(southFacingRoverAtThirdQuadrant.getYCoordinate(), initialCoordinateOfSouthFacingRoverAtThirdQuadrant);
    }

    @Test
    public void testWhenNegativeValueIsPassedToMoveBackward() {
        roverAtOrigin.moveBackward(-5);
        southFacingRoverAtThirdQuadrant.moveBackward(-1);
        assertEquals(roverAtOrigin.getYCoordinate(), 5);
        assertEquals(southFacingRoverAtThirdQuadrant.getYCoordinate(), -3);
    }

    @Test
    public void testWhenRoverTurnsLeft() {
        roverAtOrigin.turnLeft();
        southFacingRoverAtThirdQuadrant.turnLeft();
        assertEquals(roverAtOrigin.getDirection(), "W");
        assertEquals(southFacingRoverAtThirdQuadrant.getDirection(), "E");
    }

    @Test
    public void testWhenRoverTurnsRight() {
        roverAtOrigin.turnRight();
        southFacingRoverAtThirdQuadrant.turnRight();
        assertEquals(roverAtOrigin.getDirection(), "E");
        assertEquals(southFacingRoverAtThirdQuadrant.getDirection(), "W");
    }

    @Test
    public void testEmergencyTransmitterIsCalledOnce() {
        roverAtOrigin.moveBackward(3);
        verify(transmitter, times(1)).transmit("out of range - send distress satellite transmission signal", 0, -3);
    }

    @Test
    public void testSampleScenario() {
        roverAtOrigin.moveForward(5);
        roverAtOrigin.turnRight();
        roverAtOrigin.moveForward(2);
        roverAtOrigin.turnRight();
        roverAtOrigin.moveForward(3);
        roverAtOrigin.turnLeft();
        roverAtOrigin.moveBackward(1);
        roverAtOrigin.turnRight();
        assertEquals(roverAtOrigin.getDirection(), "S");
        assertEquals(roverAtOrigin.getXCoordinate(), 1);
        assertEquals(roverAtOrigin.getYCoordinate(), 2);
    }
}
