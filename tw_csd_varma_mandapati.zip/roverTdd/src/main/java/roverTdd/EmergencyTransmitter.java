
package roverTdd;

public class EmergencyTransmitter {

    public void Transmit(String msg, int xCoordinate, int yCoordinate) {
            System.out.print(msg);
    }

}
