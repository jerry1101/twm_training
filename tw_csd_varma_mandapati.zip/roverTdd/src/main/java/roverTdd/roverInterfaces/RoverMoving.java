package roverTdd;

public interface RoverMoving
{
    public void MoveForward(int spots);
    public void MoveBackward(int spots);
}
