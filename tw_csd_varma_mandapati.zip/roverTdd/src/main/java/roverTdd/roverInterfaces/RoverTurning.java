package roverTdd;

public interface RoverTurning {
    public void TurnLeft();

    public void TurnRight();
}