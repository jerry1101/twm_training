package roverTdd;

import org.junit.*;
import static org.junit.Assert.*;
import java.io.ByteArrayOutputStream;
import java.io.PrintStream;

public class EmergencyTransmitterTests {
    private EmergencyTransmitter emergencyTransmitter;
    private final ByteArrayOutputStream outContent = new ByteArrayOutputStream();
    private final PrintStream originalOut = System.out;

    @Before
    public void initializeEmergencyTransmitter() {
        emergencyTransmitter = new EmergencyTransmitter();
        System.setOut(new PrintStream(outContent));
    }

    @Test
    public void testMessageWasTransmitted() {
        emergencyTransmitter.Transmit("distress: in negative", -2, 5);
        assertEquals("distress: in negative", outContent.toString());
    }


    @After
    public void restoreStreams() {
        System.setOut(originalOut);
    }
}